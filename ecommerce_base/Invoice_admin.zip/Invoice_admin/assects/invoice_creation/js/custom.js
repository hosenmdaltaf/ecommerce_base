/*******************************************************************************************/

/*scroll add class*/
$(window).scroll(function() {    
    var scroll = $(window).scrollTop();

    if (scroll >= 50) {
        $("header").addClass("darkHeader");
    } else {
        $("header").removeClass("darkHeader");
    }
}); 

/*******************************************************************************************/

/*increment decrement*/


/*******************************************************************************************/

/*for dashboard menu*/
$(document).ready(function () {
    $("#accordian a").click(function () {
        var link = $(this);
        var closest_ul = link.closest("ul");
        var parallel_active_links = closest_ul.find(".active")
        var closest_li = link.closest("li");
        var link_status = closest_li.hasClass("active");
        var count = 0;

        closest_ul.find("ul").slideUp(function () {
            if (++count == closest_ul.find("ul").length)
                parallel_active_links.removeClass("active");
        });

        if (!link_status) {
            closest_li.children("ul").slideDown();
            closest_li.addClass("active");
            closest_li.siblings("li").removeClass("active");
        }
    })
})
/*for dashboard menu*/

/*******************************************************************************************/

/*for select dropdown custom*/
$(document).ready(function() {
  $('select').niceSelect();
})
/*for select dropdown custom*/

/*******************************************************************************************/

/*sidebar open close*/
$('.sidebar_button a').click(function(){
    $(this).parents("body").toggleClass("hidemenu");
});

$('.sidebar_mobile a').click(function(){
    $(this).parents("body").toggleClass("showmenu");
});

$('.custom_access').click(function(){
    $(this).parents("body").removeClass("hidemenu");
});

$('.overlay').click(function(){
    $(this).parents("body").removeClass("showmenu");
});
/*sidebar open close*/

/*******************************************************************************************/

/*wow animation*/
new WOW().init();
/*wow animation*/

/*******************************************************************************************/

/*slide for boxes*/
$('.boxes-slide').slick({
  infinite: false,
  slidesToShow: 4,
  slidesToScroll: 1,
  variableWidth: true,
  arrows:false,
   responsive: [
    {
      breakpoint: 992,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 1,
        variableWidth: false,
        autoplay: true,
        autoplaySpeed: 2000,
          infinite:true,
      }
    },
    {
      breakpoint: 767,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 1,
          variableWidth: false,
      }
    },
    {
      breakpoint: 450,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1,
           variableWidth: false,
          arrows:true,
      }
    }
  ]
});
/*slide for boxes*/

/*******************************************************************************************/

/*range date*/
$('#rangestart').calendar({
  type: 'date',
  endCalendar: $('#rangeend')
});
$('#rangeend').calendar({
  type: 'date',
  startCalendar: $('#rangestart')
});

$('#validtill').calendar();
$('#validtill1').calendar();
// $('#validtill2').calendar();
// $('#validtill3').calendar();
/*range date*/

/*******************************************************************************************/

/*active option*/
$('.options_source').click(function(){
    $(this).addClass("active");
    $(this).siblings().removeClass("active");
});
/*active option*/

/*******************************************************************************************/
/*image upload*/
$("#profile_img").click(function(e) {
    $("#img_upload").click();
});
/*image upload*/
/*******************************************************************************************/

$('.static_table table tr td a').click(function(){
    $(this).parents("tr").toggleClass("addselect");
    $(this).addClass("savebutton")
    
    $(this).text(function(i, text){
          return text === "Edit" ? "Save" : "Edit";
      })
});



/*$('#select1').on('change', function() {
     $('#select2').html('<option value="test">item3: test 1</option><option value="test2">item3: test 2</option>')
    alert();
});*/

// $(".selectpicker").selectpicker(); 
// $("#choice1").change(function () {
//     if (typeof $(this).data('options') === "undefined") {
//         /*Taking an array of all options-2 and kind of embedding it on the select1*/
//         $(this).data('options', $('#choice2 option').clone());
//     }
//     var id = $(this).val();
//     var options = $(this).data('options').filter('[data-option=' + id + ']');
//     $('#choice2').html(options);
//     $('#choice2').selectpicker('refresh');
//     $(".selectpicker").selectpicker(); 
// });


/*changeselect*/



