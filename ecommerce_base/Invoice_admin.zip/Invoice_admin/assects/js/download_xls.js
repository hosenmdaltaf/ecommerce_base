 $(".selchoices").on('click', function(){
        if($('input[class^=selchoices]:checked').length == 1){
            $('#Button3').prop('disabled', false);
        }else if($('input[class^=selchoices]:checked').length > 0){

            $('#Button3').prop('disabled', false);

        }else{
            $('#Button3').prop('disabled', true);
        }

    });




$("#selectAll").on("click", function(){

    if ($(this).hasClass('allChecked')) {
        otable.$("input[type='checkbox']").not(":disabled").prop('checked', false);
    } else {
        otable.$("input[type='checkbox']").not(":disabled").prop('checked', true);
    }
    $(this).toggleClass('allChecked');
});


$('#selectAll').click(function (e) {
        $(this).closest('table').find('td input:checkbox').not(":disabled").prop('checked', this.checked);
        if($(this).is(':checked')){
            $('#Button3').prop('disabled', false);

        }else{

            $('#Button3').prop('disabled', true);

        }
    });




 function confirmXls(){

    var query_ids = [];


    //checkboxes should have a general class to traverse
    var rowcollection = otable.$(".selchoices:checked", {"page": "all"});

    //Now loop through all the selected checkboxes to perform desired actions

    rowcollection.each(function(index,elem){
        //You have access to the current iterating row
        var checkbox_value = $(elem).attr('data-attr-value');
        query_ids.push(checkbox_value)
        //Do something with 'checkbox_value'
    });


    swal({
        title: "Download XLS",
        text: "You want to Download XLS",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Yes",
        closeOnConfirm: false
    }, function (isConfirm) {
        if (!isConfirm) return;
        $.ajax({
            url: "/export_users_xls/",
            type: "POST",
            data: {'query_ids':JSON.stringify(query_ids)

            },
            dataType: 'json',
            success: function (data) {
                if (data.success == true){
swal({
  title: "Success!",
  text: "click on ok to Download XLS",
  type: "success",

  showConfirmButton: true
}, function(){
      location.reload();
      window.location.href = "/export_users_xlss/";
},
);

                }
            },
            error: function (xhr, ajaxOptions, thrownError) {
                swal("Error deleting!", "Please try again", "error");
            }
        });
    });


 }

