 $(".selchoices").on('click', function(){
        if($('input[class^=selchoices]:checked').length == 1){
            $('#Button2').prop('disabled', false);
        }else if($('input[class^=selchoices]:checked').length > 0){

            $('#Button2').prop('disabled', false);

        }else{
            $('#Button2').prop('disabled', true);
        }

    });

//$("#apply_btn").click(function(){
//  var fromDate = $('#fromDate').val();
//  var toDate = $('#toDate').val();
//    console.log("XZC");
//  var url = $("#idForm").attr("data-cities-url");
//  $.ajax({
//    url: url,
//    type:"POST",
//    data:{
//      'fromDate':fromDate,
//      'toDate':toDate,
//    },
//
//    success: function (data) {
//      if (data.form_is_valid) {
//
//        $("#example tbody").html(data.html_book_list);
//        $(".mypage").html(data.page_div);
//
//      }
//      else {
//
//        $("#modal-book .modal-content").html(data.html_form);
//      }
//    }
//  });
//  return false;
//});

var otable = $('#example').DataTable({
    "pageLength": 5,
    responsive: {
        details: {
            renderer: function(api, rowIdx, columns) {
                var data = $.map(columns, function(col, i) {
                    return col.hidden ?
                        '<tr data-dt-row="' + col.rowIndex + '" data-dt-column="' + col.columnIndex + '">' +
                        '<td>' + col.title + ':' + '</td> ' +
                        '<td>' + col.data + '</td>' +
                        '</tr>' :
                        '';
                }).join('');

                return data ? $('<table/>').append(data) : false;
            }
        }
    }

}); // end of DataTable

$("#selectAll").on("click", function(){

    if ($(this).hasClass('allChecked')) {
        otable.$("input[type='checkbox']").not(":disabled").prop('checked', false);
    } else {
        otable.$("input[type='checkbox']").not(":disabled").prop('checked', true);
    }
    $(this).toggleClass('allChecked');
});


$('#selectAll').click(function (e) {
        $(this).closest('table').find('td input:checkbox').not(":disabled").prop('checked', this.checked);
        if($(this).is(':checked')){
            $('#Button2').prop('disabled', false);

        }else{

            $('#Button2').prop('disabled', true);

        }
    });




 function confirmDelete(){

    var query_ids = [];

    //checkboxes should have a general class to traverse
    var rowcollection = otable.$(".selchoices:checked", {"page": "all"});

    //Now loop through all the selected checkboxes to perform desired actions

    rowcollection.each(function(index,elem){
        //You have access to the current iterating row
        var checkbox_value = $(elem).attr('data-attr-value');
        query_ids.push(checkbox_value)
        //Do something with 'checkbox_value'
    });


    swal({
        title: "Are you sure?",
        text: "You want to generate Copy/Transfer request for selected invoices",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Yes",
        closeOnConfirm: false
    }, function (isConfirm) {
        if (!isConfirm) return;
        $.ajax({
            url: "/request_for_admin_approval/",
            type: "POST",
            data: {'query_ids':JSON.stringify(query_ids)

            },
            dataType: 'json',
            success: function (data) {
                if (data.success == true){
                    swal({
                          title: "Done!",
                          text: "Request has been successfully sent to Admin for Approval",
                          type: 'success',

                        }, function() {
                             location.reload();
                       }
                        );

                }
            },
            error: function (xhr, ajaxOptions, thrownError) {
                swal("Error deleting!", "Please try again", "error");
            }
        });
    });


 }

