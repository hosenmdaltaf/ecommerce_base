    temp = []
    $('.custom_access').each(function(){
        txt = $(this).attr('data-attr-value');
        temp.push(txt);
        $(this).hide()
     });
// alert(temp);
// 'module_list' is defined in header and home.html

    for (var i = 0; i < module_list.length; i++) {
        for (var j = 0; j < temp.length; j++) {
                if ( module_list[i] == temp[j]) {
                    $('.custom_access').each(function(){
                        txt = $(this).attr('data-attr-value');
                        if (txt == temp[j]){
                            $(this).show();
                        }
                     });
                }
        }

    }
